<!DOCTYPE HTML>
<!--version: 1.4 Apr 2013  ref: Phil Callahan pec50@hotmail.com -->
<!--version: 1.41 Apr 2013  zscore added to output -->
<!--version: 1.42 Apr 2013 improved visuals & alpha student roster -->
<!--version: 1.43 May 2020 ob_start clause and outputcsv file overwrites in cattraxfiles -->
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>cattrax</title>
<style media="screen" type="text/css">
/* group i/o form */
body {
	font-family: verdana, arial, sans serif;
	font-size: 12px;
}

form {
    margin:30px auto;
}

h1 {
	background: transparent url("images/BUD.png") no-repeat;
	font: 20px Verdana, Arial, Helvetica, sans-serif;
	line-height: 30px;
	margin: 30px;
	padding-left: 37px;
}

ul {
	list-style: none;
	margin: 20px;
	padding: 0;
}

formcaption {
	font: 12px Verdana, Arial, Helvetica, sans-serif;
	font-weight: bold;
	border-style: none;
	text-align: left;
	padding: 4px;
	font-size: 100%;
	background-color: #f8f8ff;
	margin: 0px;
}


/* group table output */
table {
	font-family: verdana, arial, sans serif;
	font-size: 12px;
	border-style: none;
	border-width: 1px;
	border-color: #DCDCDC;
	border-collapse: collapse;
}

caption {
	font-weight: bold;
	display: table-caption;
	border-style: none;
	border-width: 1px;
	text-align: left;
	padding: 4px;
	font-size: 100%;
	background-color: #DCDCDC;
}

th {
	border-style: none;
	border-width: 1px;
	text-align: center;
	padding: 4px;
	font-size: 100%;
	background-color: #DCDCDC;
}

td {
	min-width: 18px;
	border: 1px solid #ffffff;
	border-width: 0 1px 1px 0;
	padding: 4px;
	text-align: center;
	font-size: 100%;
	background-color: #f8f8ff;
}

td#CI {
	/* font-weight: bold;
	color: red; */
	background-color: salmon;
}

td#Correct {
	background-color: gray;
	font-size: 85%;
}

td#Incorrect {
	background-color: salmon;
	font-size: 85%;
}

td#Tot {
	background-color: lightgreen;
}

td#Range {
	background-color: lightgreen;
	font-size: 85%;
}

td#forceleft {
	border-style: none;
	border-width: 1px;
	padding: 4px;
	text-align: left;
	font-size: 100%;
	background-color: #f8f8ff;
}

td#smalltype {
	font-size: 90%;
}

td#forcerightsmallbold {
	font-weight: bold;
	border-style: none;
	border-width: 1px;
	padding: 4px;
	text-align: left;
	font-size: 90%;
	background-color: #f8f8ff;
}

td#forceleftsmall {
	border-style: none;
	border-width: 1px;
	padding: 4px;
	text-align: left;
	font-size: 90%;
	background-color: #f8f8ff;
}


td#forcerightsmall {
	border-style: none;
	border-width: 1px;
	padding: 4px;
	text-align: right;
	font-size: 90%;
	background-color: #f8f8ff;
}

.border-bottom {
	border-bottom: 1px dotted grey;
}
</style>
</head>
<BODY>
<?php
if(isset($_GET['action'])){
	$action = $_GET['action'];
	Downloadcsv($action);
	exit;
} elseif(!isset($_POST['submit'])){
?>

	<h1>CatTrax 1.43</h1>
	<form method="post" action="index.php" enctype="multipart/form-data">
		<formcaption>Input Data Source (Select CSV file, Moodle file or Scantron with data & key files)</formcaption>
		<ul>
			<li><input type="radio" name="typeinput" value="csv" checked = "checked" />CSV - Windows comma delimited csv<br /></li>
			<!-- <li><input type="radio" name="typeinput" value="drupal" />Drupal - csv<br /></li> -->
			<li><input type="radio" name="typeinput" value="moodle" />Moodle - csv<br /></li>
			<li><input type="radio" name="typeinput" value="scantron" />Scantron - data txt & key csv<br /></li>
			<br />
			<li>Data File</li>
			<li><input type="file" name="inputfile" id="inputfile"></li>
			<br />
			<li>Key File -- Scantron only</li>
			<li><input type="file" name="inputfilekey" id="inputfilekey"></li>
		</ul>
		<ul>
			<li><input type="submit" name="submit" type="submit" value="submit">&nbsp &nbsp &nbsp &nbsp<a href="cattraxhelp.html">CatTrax Help </a></li>
		</ul>
	</form>

<?php
} else {
	//set input vars
	$inputfile = $_FILES['inputfile']['tmp_name'];        //all data files
	$inputfilename = $_FILES['inputfile']['name'];        //data source file name
	$inputfilekey = $_FILES['inputfilekey']['tmp_name'];  //scantron file key
	$inputfilekeyname = $_FILES['inputfilekey']['name'];  //scrantron key source file name
	$typeinput = $_POST['typeinput'];
	$typeia = "";
	if ($typeinput == "scantron") {       //parse csv key file and scantron (mc participant responses) txt file
		ScantronInput($inputfile, $inputfilekey, $typeinput, $typeia);
	} else if ($typeinput == "moodle") {  //parse moodle (multiple choice one answer key) csv input file (moodle.csv) and extract operating parameters
		MoodleInput($inputfile, $inputfilekey, $typeinput, $typeia);
	} else if ($typeinput == "drupal") {  //parse drupal survey forms (mc one answer key) csv input file
		DrupalInput($inputfile, $inputfilekey, $typeinput, $typeia);
	} else if ($typeinput == "csv") {     //parse csv input file and extract operating parameters
		CSVInput($inputfile, $inputfilekey, $typeinput, $typeia);
	} else {
		exit("Terminated: no data file");
	}
	//remake input file into a standard csv
	CSVReformatInput($inputarray, $nosturecs, $notestitems, $notestkeys);
	//load test answer keys
	ReadAnsKeys($inputarray, $nosturecs, $notestitems, $notestkeys);
	//load and score participant records
	ReadParticipants($inputarray, $ansarray, $nosturecs, $notestitems, $notestkeys);
	//count number of potential unique item responses per item
	LoadUniqueResp($recrdstuarray, $inputarray, $nosturecs, $notestitems, $notestkeys);
	PurgeOmits($recrdstuarray, $ansarray, $itemarray, $nosturecs, $notestitems, $notestkeys, $itprg);
	//total correct responses for students, IA group size, SD & Mean
	TotParticipant($recrdstuarray, $nosturecs, $notestitems, $notestkeys);
	//sort rows by descending testee scores
	SortRows($recrdstuarray, $inputarray, $nosturecs, $notestkeys, $notestitems);
	//total correct responses for items and proportion correct, proportion incorrect & kr20
	TotItem($recrdstuarray, $nosturecs, $notestitems, $notestkeys, $zsd);
	//sort cols by descending item score
	SortCols($recrdstuarray, $ansarray, $inputarray, $itemarray, $nosturecs, $notestkeys, $notestitems, $totopts);
	//calculate row ci
	CalcRowCI($recrdstuarray, $nosturecs, $notestitems, $notestkeys);
	//calculate column ci
	CalcColCI($recrdstuarray, $nosturecs, $notestitems, $notestkeys);
	//calculate item biserial correlation
	CalcBiserialCorr($recrdstuarray, $notestitems, $nosturecs, $zm);
	//calculate ia item descrimination
	CalcIAItemDisc($recrdstuarray, $nosturecs, $notestitems, $typeia);
	//display test summary
	DispTestTOC();
	DispTestSummary($inputarray, $nosturecs, $notestitems, $notestkeys, $recrdstuarray, $inputfile, $zm, $zsd, $zkr20, $inputfilename);
	ExportTestSummary($inputarray, $nosturecs, $notestitems, $notestkeys, $recrdstuarray, $inputfile, $zm, $zsd, $zkr20, $inputfilename);
	//display teacher take caution table
	DisplayTeacherCaution($inputarray, $nosturecs, $notestitems, $notestkeys, $recrdstuarray, $iagroupsize, $iatopgrp, $iabotgrp, $zm, $zsd);
	//display sp table
	DisplaySP($inputarray, $nosturecs, $notestitems, $notestkeys, $recrdstuarray, $iagroupsize, $iatopgrp, $iabotgrp, $zm, $zsd);
	ExportSP($inputarray, $nosturecs, $notestitems, $notestkeys, $recrdstuarray, $iagroupsize, $iatopgrp, $iabotgrp, $zm, $zsd);
	//perform item analysis
	CalcIAProblem($inputarray, $itemarray, $recrdstuarray, $ansarray, $nosturecs, $notestkeys, $notestitems, $iagroupsize, $totopts, $iatopgrp, $iabotgrp, $typeia);
	//display roster results
	SortName($recrdstuarray, $inputarray, $nosturecs, $notestkeys, $notestitems);
	SortItem($recrdstuarray, $ansarray, $inputarray, $itemarray, $nosturecs, $notestkeys, $notestitems, $totopts);
	$keyptr = 0;
	DisplayRoster($inputarray, $nosturecs, $notestitems, $notestkeys, $recrdstuarray, $iagroupsize, $iatopgrp, $iabotgrp, $zm, $zsd, $keyptr);
	//multiple answer key analysis
	for ($keyptr=1; $keyptr < $notestkeys; $keyptr++) {
		ScoreParticipants($inputarray, $ansarray, $nosturecs, $notestitems, $notestkeys, $keyptr);
		TotParticipant($recrdstuarray, $nosturecs, $notestitems, $notestkeys);
		SortRows($recrdstuarray, $inputarray, $nosturecs, $notestkeys, $notestitems);
		TotItem($recrdstuarray, $nosturecs, $notestitems, $notestkeys, $zsd);
		SortCols($recrdstuarray, $ansarray, $inputarray, $itemarray, $nosturecs, $notestkeys, $notestitems, $totopts);
		CalcRowCI($recrdstuarray, $nosturecs, $notestitems, $notestkeys);
		CalcColCI($recrdstuarray, $nosturecs, $notestitems, $notestkeys);
		CalcBiserialCorr($recrdstuarray, $notestitems, $nosturecs, $zm);
		CalcIAItemDisc($recrdstuarray, $nosturecs, $notestitems, $typeia);
		DispTestSummaryExtra($inputarray, $nosturecs, $notestitems, $notestkeys, $recrdstuarray, $inputfile, $zm, $zsd, $zkr20, $inputfilename, $keyptr);
		ExportTestSummary($inputarray, $nosturecs, $notestitems, $notestkeys, $recrdstuarray, $inputfile, $zm, $zsd, $zkr20, $inputfilename);
		DisplaySP($inputarray, $nosturecs, $notestitems, $notestkeys, $recrdstuarray, $iagroupsize, $iatopgrp, $iabotgrp, $zm, $zsd);
		SortName($recrdstuarray, $inputarray, $nosturecs, $notestkeys, $notestitems);
		SortItem($recrdstuarray, $ansarray, $inputarray, $itemarray, $nosturecs, $notestkeys, $notestitems, $totopts);
		DisplayRoster($inputarray, $nosturecs, $notestitems, $notestkeys, $recrdstuarray, $iagroupsize, $iatopgrp, $iabotgrp, $zm, $zsd, $keyptr);
		ExportSP($inputarray, $nosturecs, $notestitems, $notestkeys, $recrdstuarray, $iagroupsize, $iatopgrp, $iabotgrp, $zm, $zsd);
	}
	//name csv export file for export
	NameExportCSV();
}
// ----------------------------------------------------------------------

function ScantronInput($inputfile, $inputfilekey, $typeinput, $typeia) {
	//read inputscantronkey.csv file into catrax inputarray format
	//read test key as: ,,,followed by ans key csv format
	//read inputscantron.txt file into cattrax inputarray format
	//data ... record shows last name, first name, instit, dept, email, start, stop, time, grade, 1st resp, 1st key, 2nd resp, 2nd key, 3rd resp, 3rd key ...
	//$inputarray layout
	//test key to show as: ,,,followed by ans key
	//test takers to show as: id, first name, last name, responses
	//inputarray layout
	// 0  1     2        3456789 ...
	//0                  anskey ...
	//1id first lastname itemresponses ...
	//2 ...
	global $inputarray, $nosturecs, $notestitems, $notestkeys, $inputfile, $inputfilekey, $typeia;
	//read ans key
	$notestkeys = 0; $notestitems = 0; $numrec = 0;
	//$inputfilekey = "inputscantronkey.csv";
	if (($handle = fopen("$inputfilekey", "r")) !== FALSE) {
		while (($data = fgetcsv($handle, 0, ",")) !== FALSE) {
			$numfield = count($data);           //determine tot no of record fields
			if ($numfield > 1) {                //abnormal terminate when/if excel csv export file shows eof null records
				$notestitems = ($numfield);
				if ($numrec == 0) {
					for ($c = 0; $c < 3; $c++) {
						$inputarray[$numrec][$c] = ""; //first three cols nulled in ans key, record 0
					}
				}
				for ($c = 0; $c < $numfield; $c++) {
					$inputarray[$numrec][$c + 3] = $data[$c]; //build key
				}
				$numrec++;
			}
		}
		$notestkeys = $numrec;
		fclose($handle);
	} else {
		exit("Terminated: no data");
	}
	//read student data records
	$nosturecs = 0; $numrec = $notestkeys;
	//$inputfile = "inputscantron.txt";
	if (($handle = fopen("$inputfile", "r")) !== FALSE) {
		while (($data = fgetcsv($handle, 0, "'")) !== FALSE) {
			$numfield = count($data); //determine tot no of record fields
			//abnormal terminate when/if scantron export file shows additional null records
			if ($numfield > 1) {
				//check for scantron supported id field
				if ($data[30] == "") {
					$inputarray[$numrec][0] = $numrec; //create stu id using local counter
				} else {
					$inputarray[$numrec][0] = $data[30]; //transfer stu id
				}
				$inputarray[$numrec][1] = $data[29]; //set participant name
				$inputarray[$numrec][2] = "";
				$colinputarray = 3; //load responses starting at col 3
				for ($c = 49; $c < $notestitems + 49; $c++) {
					$inputarray[$numrec][$colinputarray] = $data[$c]; //build stu response
					$colinputarray++;
				}
				$numrec++;
			}
		}
		fclose($handle);
		$nosturecs = $numrec - $notestkeys; //assumes one or more test keys
		if ($nosturecs < 30) {
			$typeia = "split";
		} else {
			$typeia = "thirds";
		}
	} else {
		exit("Terminated: no data");
	}
}


function MoodleInput($inputfile, $inputfilekey, $typeinput, $typeia) {
	//read inputmoodle.csv file into cattrax inputarray format
	//**moodle settings: export must be set to test/results/responses**
	// - That are graded for each user (Highest grade)
	// - Summary of the response given
	// - Summary of the right answer
	// - then Show report
	// - then Download table as a comma separated values text file
	// - then find the file for loading into cattrax
	//moodle 1st record shows column lables
	//moodle 2nd ... record shows last name, first name, instit, dept, email, start, stop, time, grade, 1st resp, 1st key, 2nd resp, 2nd key, 3rd resp, 3rd key ...
	//$inputarray layout
	//test key to show as: ,,,followed by ans key
	//test takers to show as: id, first name, last name, responses
	//inputarray layout
	// 0  1     2        3456789 ...
	//0                  anskey ...
	//1id first lastname itemresponses ...
	//2 ...
	global $inputarray, $nosturecs, $notestitems, $notestkeys, $inputfile, $typeia;
	$nosturecs = 0;
	$notestitems = 0;
	$notestkeys = 1;
	$numrec = 0;
	//$inputfile = "inputmoodle.csv";
	if (($handle = fopen("$inputfile", "r")) !== FALSE) {
		while (($data = fgetcsv($handle, 0, ",")) !== FALSE) {
			$numfield = count($data); //determine tot no of record fields
			//abnormal terminate when/if moodle export file shows additional null records
			if ($numfield > 1) {
				$notestitems = ($numfield - 9)/2; //assumes 9 demographic fields & item responses and key responses
				if ($numrec == 0) {
					for ($c = 0; $c < 3; $c++) {
						$inputarray[0][$c] = ""; //first three cols nulled in ans key, record 0
					}
				} else {
					$inputarray[$numrec][0] = $numrec; //create stu id using local counter
					$inputarray[$numrec][1] = $data[1]; //set first name
					$inputarray[$numrec][2] = $data[0]; //set last name
				}
				//load responses starting at col 3 reading from data csv starting at col 9
				$colinputarray = 3;
				for ($c = 9; $c < $numfield; $c += 2) {
					$inputarray[$numrec][$colinputarray] = $data[$c]; //build stu response
					$inputarray[0][$colinputarray] = $data[$c + 1]; //build ans key
					$colinputarray++;
				}
				$numrec++;
			}
		}
		fclose($handle);
		$nosturecs = $numrec - $notestkeys; //assumes one or more test keys
		if ($nosturecs < 30) {
			$typeia = "split";
		} else {
			$typeia = "thirds";
		}
	}
}


function DrupalInput($inputfile, $inputfilekey, $typeinput, $typeia) {
	//read inputdrupal.csv file into cattrax inputarray format
	//drupal layout
	//1st rec: CatTrax Test
	//2nd rec: Submission Details
	//3rd rec: UID   Username   a,c,d,a,b,c	q01 - What is the right answer? ...
	//4th rec: 61    Student01               a ...
	//$inputarray layout
	//test key to show as: ,,,followed by ans key
	//test takers to show as: id, first name, last name, responses
	//inputarray layout
	// 0  1     2        3456789 ...
	//0                  anskey ...
	//1id first lastname itemresponses ...
	//2 ...
	global $inputarray, $nosturecs, $notestitems, $notestkeys, $inputfile, $typeia;
	$nosturecs = 0;
	$notestitems = 0;
	$notestkeys = 1;
	$numrec = 0;
	//$inputfile = "inputdrupal.csv";
	if (($handle = fopen("$inputfile", "r")) !== FALSE) {
		while (($data = fgetcsv($handle, 0, ",")) !== FALSE) {
			$numfield = count($data);
			 //create anskey
			if ($numrec == 2) {
				$a = $data[2];
				$aarray = explode(",",$a);
				$acnt = count($aarray);
				$inputarray[0][0] = ""; $inputarray[0][1] = ""; $inputarray[0][2] = ""; //null 3 fields before key
				for ($ac=0; $ac < $acnt; $ac++) {
					$inputarray[0][$ac + 3] = $aarray[$ac];
				}
			}
			//load participant data
			if ($numrec > 2) { //skip first three records then load participants
				$inputarray[$numrec - 2][0] = $data[0]; //id
				$inputarray[$numrec - 2][1] = $data[1]; //name
				$inputarray[$numrec - 2][2] = "";       //not used
				for ($c=3; $c < $numfield; $c++) {  //responses
					if ($data[$c] == "") {
						$inputarray[$numrec - 2][$c] = ".";
					} else {
						$inputarray[$numrec - 2][$c] = $data[$c];
					}
				}
			}
			$numrec++;
		}
		fclose($handle);
		$notestitems = $numfield - 3; //assumes id, name, ans cols
		$nosturecs = $numrec - ($notestkeys + 2); //assumes one or more test keys and two null recs
		if ($nosturecs < 30) {
			$typeia = "split";
		} else {
			$typeia = "thirds";
		}
	}
}


function CSVInput($inputfile, $inputfilekey, $typeinput, $typeia) {
	//read input.csv file
	//file contains test key(s) and test taker(s) records comma delimited csv
	//test key(s) records show as: ,,,followed by ans key comma delimited
	//test takers records show as: id, first name, last name, responses comma delimited
	//inputarray layout
	// 0  1     2        3456789 ...
	//0                  anskey ...
	//1id first lastname itemresponses ...
	//2 ...
	global $inputarray, $nosturecs, $notestitems, $notestkeys, $inputfile, $typeia;
	$nosturecs = 0;
	$notestitems = 0;
	$notestkeys = 0;
	$numrec = 0;
	//$inputfile = "input.csv";
	if (($handle = fopen("$inputfile", "r")) !== FALSE) {
		while (($data = fgetcsv($handle, 0, ",")) !== FALSE) {
			$numfield = count($data);
			//count num of test keys based on null first field
			if ($data[0] == "") {
					$notestkeys++;
			}
			//parse fields
			for ($c=0; $c < $numfield; $c++) {
				$inputarray[$numrec][$c] = $data[$c];
			}
			$numrec++;
		}
		fclose($handle);
		$notestitems = $numfield - 3; //assumes id, first name, last name fields
		$nosturecs = $numrec - $notestkeys; //assumes one or more test keys
		if ($nosturecs < 30) {
			$typeia = "split";
		} else {
			$typeia = "thirds";
		}
	} else {
		exit("Terminated: no data");
	}
}


Function CSVReformatInput($inputarray, $nosturecs, $notestitems, $notestkeys) {
	//remake input file into standard csv to allow user editing
	$fp = fopen('./cattraxfiles/outputcsv.csv', 'w');
	foreach ($inputarray as $fields) {
		fputcsv($fp, $fields);
	}
	$line1 = array(' '); //blank line spacer
	fputcsv($fp, $line1);
	$line1 = array('****** Cattrax results follow for the above data file ******');
	fputcsv($fp, $line1);
	$line1 = array(' '); //blank line spacer
	fputcsv($fp, $line1);
	fclose($fp);
}


function ReadAnsKeys($inputarray, $nosturecs, $notestitems, $notestkeys) {
	//load test answer key(s)
	//ansarray layout
	// 0123456789 ...
	//0   anskey ...
	global $ansarray, $itprg;
	$itprg = 0;
	for ($row=0; $row < $notestkeys; $row++) {
		for ($col=0; $col < $notestitems + 3; $col++) {
			$ansarray[$row][$col] = $inputarray[$row][$col];
			//check for item purge flag (.)
			if ($ansarray[$row][$col] == ".") {
				$itprg = $itprg + 1;
			}
		}
	}
}


function ReadParticipants($inputarray, $ansarray, $nosturecs, $notestitems, $notestkeys) {
	//load and score participant records for first ans key
	//develop participant record in recrdstuarray
	//recrdstuarray layout
	// 0  1     2        34567891011...n     n+1       n+2 n+3
	//0id first lastname scoredresponses     score tot CI  SDs
	//nid first lastname scoredresponses 	 score tot CI  SDs
	//n+1                item nos 123...
	//n+2                item tot...
	//n+3                item CI
	//n+4                item discrimination
	//n+5                item biserial
	global $recrdstuarray;
	//initialize array
	for ($row=0; $row < $nosturecs + 5; $row++) {
		for ($col=0; $col < $notestitems + 6; $col++) {
			$recrdstuarray[$row][$col] = "";
		}
	}
	for ($row=0; $row < $nosturecs; $row++) {
		//load participant id and name
		for ($col=0; $col < 3; $col++) {
			$recrdstuarray[$row][$col] = $inputarray[$row + $notestkeys][$col];
		}
		//score participant's item response
		for ($col=3; $col < $notestitems + 3; $col++) {
			if ($inputarray[$row + $notestkeys][$col] == $ansarray[0][$col]) {
				$recrdstuarray[$row][$col] = 1;
			} else {
				$recrdstuarray[$row][$col] = 0;
			}
		}
	}
	//create test item numbering
	$testitem = 0;
	for ($col=3; $col < $notestitems + 3; $col++) {
		$testitem++;
		$recrdstuarray[$nosturecs][$col] = $testitem; //load sequencial item numbers
	}
}


function ScoreParticipants($inputarray, $ansarray, $nosturecs, $notestitems, $notestkeys, $keyptr) {
	//score participant records for multiple ans keys
	global $recrdstuarray, $keyptr;
	for ($row=0; $row < $nosturecs; $row++) {
		//score participant's item response
		for ($col=3; $col < $notestitems + 3; $col++) {
			if ($inputarray[$row + $notestkeys][$col] == $ansarray[$keyptr][$col]) {
				if ($recrdstuarray[$row][$col] == 0) { //toggle to current correct
					$recrdstuarray[$row][$col] = 1;
				}
			}
		}
	}
}


function LoadUniqueResp($recrdstuarray, $inputarray, $nosturecs, $notestitems, $notestkeys) {
	//scan student array for responses, identifying uniques per item for item analysis calcs
	//itemarray layout
	// 0123                    4                    5                    678 ...
	//0   total uniques 1      total uniques 2      total uniques 3 ...
	//1   response 1           response 1           response 1
	//2   response 2           response 2           response 2
	global $itemarray, $totopts;
	//initialize itemarray for maximum 20 possible unique responses
	for ($row=0; $row < 20; $row++) {
		for ($col=0; $col < $notestitems + 3; $col++) {
			$itemarray[$row][$col] = "";
		}
	}
	$totopts = 0;
	for ($col=3; $col < $notestitems + 3; $col++) {
		$totunique = 0;
		for ($row=$notestkeys; $row < $nosturecs + $notestkeys; $row++) {
			//scan for existing responses
			for ($cnt=1; $cnt < $totunique + 2; $cnt++) {
				$resfound=0;
				if ($inputarray[$row][$col] == $itemarray[$cnt][$col]) {
					$resfound = 1;
					$cnt=$totunique + 2;
				}
			}
			if ($resfound == 0) {
				$totunique ++;
				$itemarray[$totunique][$col] = $inputarray[$row][$col]; //store unique item response identifyer
			}
		}
		$itemarray[0][$col] = $totunique; //store max no unique responses per item
	}
	//max number of responses of any one item in entire test
	for ($itcol=3; $itcol < $notestitems + 3; $itcol++) {
		if ($itemarray[0][$itcol] > $totopts) {
			$totopts = $itemarray[0][$itcol];
		}
	}
}


function PurgeOmits ($recrdstuarray, $ansarray, $itemarray, $nosturecs, $notestitems, $notestkeys, $itprg) {
	//check for found item purge flag and shift arrays
	//ansarray layout
	// 0123456789 ...
	//0   anskey ...

	//recrdstuarray layout
	// 0  1     2        34567891011...n     n+1       n+2 n+3
	//0id first lastname scoredresponses     score tot CI  cond sem
	//nid first lastname scoredresponses 	 score tot CI  cond sem
	//n+1                item nos 123...
	//n+2                item tot...
	//n+3                item CI
	//n+4                item discrimination
	//n+5                item biserial
	//row total      $recrdstuarray[$row][$notestitems + 3]
	//row ci         $recrdstuarray[$row][$notestitems + 4]
	//row cond sem   $recrdstuarray[$row][$notestitems + 5]
	//col item nos   $recrdstuarray[$nosturecs][$col]
	//col total      $recrdstuarray[$nosturecs + 1][$col]
	//col ci         $recrdstuarray[$nosturecs + 2][$col]
	//col discrim    $recrdstuarray[$nosturecs + 3][$col]
	//col biserial   $recrdstuarray[$nosturecs + 4][$col]

	//itemarray layout
	// 0123                    4                    5                    678 ...
	//0   total uniques item 1 total uniques item 2 total uniques item 3 ...
	//1   response 1           response 1           response 1
	//2   response 2           response 2           response 2
	//3   ...
	global $recrdstuarray, $ansarray, $itemarray, $notestitems, $notestkeys;
	//if ($itprg == 1) {
	for ($omits=0; $omits < $itprg; $omits++) {
		$row = 0;
		for ($col=0; $col < $notestitems + 3; $col++) {
			//check for item purge flag (.)
			if ($ansarray[$row][$col] == ".") {
				// shift arrays left one item -- notestitems decremented 1 due to shiftcol+1
				for ($shiftrow=0; $shiftrow < $nosturecs + 5; $shiftrow++) {
					for ($shiftcol=$col; $shiftcol < $notestitems + 5; $shiftcol++) {
						$recrdstuarray[$shiftrow][$shiftcol] = $recrdstuarray[$shiftrow][$shiftcol + 1];
					}
				}
				for ($shiftcol=$col; $shiftcol < $notestitems + 2; $shiftcol++) {
					for ($shiftrow=0; $shiftrow < 20; $shiftrow++) { //unique item responses for ia
						$itemarray[$shiftrow][$shiftcol] = $itemarray[$shiftrow][$shiftcol + 1];
					}
					for ($shiftrow=0; $shiftrow < $notestkeys; $shiftrow++) { //ans key
						$ansarray[$shiftrow][$shiftcol] = $ansarray[$shiftrow][$shiftcol + 1];
					}
				}
				$notestitems = $notestitems - 1; //decrement no of items
			}
		}
	}
}


function TotParticipant ($recrdstuarray, $nosturecs, $notestitems, $notestkeys) {
	//total correct responses for participant $recrdstuarray[$row][$notestitems + 3]
	//row cond sem for participant $recrdstuarray[$row][$notestitems + 5], IA group size, SD & Mean
	global $recrdstuarray, $zsd, $zm;
	$sum = 0;
	$sumsq = 0;
	for ($row=0; $row < $nosturecs; $row++) {
		$rowsum = 0;
		for ($col=3; $col < $notestitems + 3; $col++) {
			$rowsum = $rowsum + $recrdstuarray[$row][$col];
		}
		$recrdstuarray[$row][$notestitems + 3] = $rowsum; //total correct for student
		$scorerrvar = (($recrdstuarray[$row][$notestitems + 3] * ($notestitems - $recrdstuarray[$row][$notestitems + 3])) / ($notestitems - 1)); //score error variance
		$recrdstuarray[$row][$notestitems + 5] = round(sqrt($scorerrvar), 2); //conditional sem
		$sum = $sum + $rowsum;
		$sumsq = $sumsq + ($rowsum * $rowsum);
	}
	$zsd = sqrt(($sumsq - (($sum * $sum) / $nosturecs)) / $nosturecs); //Group standard deviation
	$zm = $sum / $nosturecs; //Group mean
}


function TotItem($recrdstuarray, $nosturecs, $notestitems, $notestkeys, $zsd) {
	//total correct responses for items $recrdstuarray[$nosturecs + 1][$col] and kr20
	global $recrdstuarray, $zp, $zq, $zkr20;
	//store item no in recrdstuarray bottom row
	for ($col=0; $col < 3; $col++) {
			$recrdstuarray[$nosturecs][$col] = ""; //null first three cells corresponding to id and name fields
	}
	//total correct responses
	$zsumpq = 0;
	for ($col=0; $col < 3; $col++) {
			$recrdstuarray[$nosturecs + 1][$col] = " "; //null first three cells corresponding to id and name fields
	}
	$testitem = 0;
	for ($col=3; $col < $notestitems + 3; $col++) {
		$colsum = 0;
		for ($row=0; $row < $nosturecs; $row++) {
			$colsum = $colsum + $recrdstuarray[$row][$col];
		}
		$recrdstuarray[$nosturecs + 1][$col] = $colsum; //total correct for item
		$zp = $colsum / $nosturecs; //proportion correct
		$zq = ($nosturecs - $colsum) / $nosturecs; //proportion incorrect
		$zsumpq = $zsumpq + ($zp * $zq);
	}
	$zkr20 = (($notestitems / ($notestitems  - 1)) * ((($zsd * $zsd) - $zsumpq) / ($zsd * $zsd))); //zscore calc
}


function SortRows($recrdstuarray, $inputarray, $nosturecs, $notestkeys, $notestitems) {
	//sort rows by descending testee scores
	//row total--stu correct tot--$recrdstuarray[$row][$notestitems + 3]
	global $recrdstuarray, $inputarray;
	$gap = (int)($nosturecs / 2);
	while ($gap >= 1) {
		$sorted = 0;
		while ($sorted == 0) {
			$sorted = 1;
			$maxrow = $nosturecs - $gap;
			for ($row=0; $row < $maxrow; $row++) {
				$rowck = $row + $gap;
				if ($recrdstuarray [$row][$notestitems + 3] < $recrdstuarray [$rowck][$notestitems + 3]) {
					for ($col=0; $col < $notestitems + 6; $col++) { //+3score tot +4CI +5SDs
						//swap stu/item scored array
						$swap = $recrdstuarray [$row][$col];
						$recrdstuarray [$row][$col] = $recrdstuarray [$rowck][$col];
						$recrdstuarray [$rowck][$col] = $swap;
					}
					for ($col=0; $col < $notestitems + 3; $col++) {
						//swap raw input array bypassing ans keys
						$swap = $inputarray[$row + $notestkeys][$col];
						$inputarray [$row + $notestkeys][$col] = $inputarray [$rowck + $notestkeys][$col];
						$inputarray [$rowck + $notestkeys][$col] = $swap;
					}
					$sorted = 0;
				}
			}
		}
		$gap = (int)($gap / 2);
	}
}


function SortCols($recrdstuarray, $ansarray, $inputarray, $itemarray, $nosturecs, $notestkeys, $notestitems, $totopts){
	//sort cols by descending item scores
	global $recrdstuarray, $ansarray, $inputarray, $itemarray;
	$gap = (int)($notestitems / 2);
	while ($gap >= 1) {
		$sorted = 0;
		while ($sorted == 0) {
			$sorted = 1;
			$maxcol = ($notestitems + 3) - $gap;
			for ($col=3; $col < $maxcol; $col++) {
				$colck = $col + $gap;
				//if ($recrdstuarray [$nosturecs + $notestkeys][$col] < $recrdstuarray [$nosturecs + $notestkeys][$colck]) {
				if ($recrdstuarray [$nosturecs + 1][$col] < $recrdstuarray [$nosturecs + 1][$colck]) {
					//swap stu/item scored array
					for ($row=0; $row < $nosturecs + 2; $row++) {
						$swap = $recrdstuarray [$row][$col];
						$recrdstuarray [$row][$col] = $recrdstuarray [$row][$colck];
						$recrdstuarray [$row][$colck] = $swap;
					}
					//sort ans key
					for ($row=0; $row < $notestkeys; $row++) {
						$swap = $ansarray[$row][$col];
						$ansarray[$row][$col] = $ansarray[$row][$colck];
						$ansarray[$row][$colck] = $swap;
					}
					//sort item responses array
					for ($row=0; $row < $totopts + 1; $row++) {
						$swap = $itemarray[$row][$col];
						$itemarray[$row][$col] = $itemarray[$row][$colck];
						$itemarray[$row][$colck] = $swap;
					}
					//sort raw input array
					for ($row=0; $row < $nosturecs + $notestkeys; $row++) {
						$swap = $inputarray [$row][$col];
						$inputarray [$row][$col] = $inputarray [$row][$colck];
						$inputarray [$row][$colck] = $swap;
					}
					$sorted = 0;
				}
			}
		}
		$gap = (int)($gap / 2);
	}
}


function CalcRowCI($recrdstuarray, $nosturecs, $notestitems, $notestkeys) {
	//calculate student ci
	//recrdstuarray layout --row ci-- $recrdstuarray[$row][$notestitems + 4]
	global $recrdstuarray, $sumstuci;
	$sumstuci = 0;
	for ($row=0; $row < $nosturecs; $row++) {
		$sum1[$row] = 0; $sum2[$row] = 0; $sum3[$row] = 0; $sum4[$row] = 0;
		for ($col=3; $col<$recrdstuarray[$row][$notestitems + 3] + 3; $col++) {
			$sum1[$row] = $sum1[$row] + (1 - $recrdstuarray[$row][$col]) * $recrdstuarray[$nosturecs + 1][$col];
			$sum3[$row] = $sum3[$row] + $recrdstuarray[$nosturecs + 1][$col];
		}
		for ($col=$recrdstuarray[$row][$notestitems + 3] + 3; $col<$notestitems + 3; $col++) {
			$sum2[$row] = $sum2[$row] + $recrdstuarray[$row][$col] * $recrdstuarray[$nosturecs + 1][$col];
		}
		for ($col=$notestitems - $recrdstuarray[$row][$notestitems + 3] + 3; $col<$notestitems + 3; $col++) {
			$sum4[$row] = $sum4[$row] + $recrdstuarray[$nosturecs + 1][$col];
		}
		//store row ci
		if (($sum3[$row] - $sum4[$row]) != 0) {
			$recrdstuarray[$row][$notestitems + 4] = (int)((($sum1[$row] - $sum2[$row])/($sum3[$row] - $sum4[$row])) * 100);
		} else {
			$recrdstuarray[$row][$notestitems + 4] = 0;
		}
		//running total student ci
		$sumstuci = $sumstuci + $recrdstuarray[$row][$notestitems + 4];
	}
}


function CalcColCI($recrdstuarray, $nosturecs, $notestitems, $notestkeys) {
	//calculate item ci
	global $recrdstuarray, $sumitci;
	$sumitci = 0;
	for ($col=3; $col < $notestitems + 3; $col++) {
		$sum1[$col] = 0; $sum2[$col] = 0; $sum3[$col] = 0; $sum4[$col] = 0;
		for ($row=0; $row < $recrdstuarray[$nosturecs + 1][$col]; $row++) {
			$sum1[$col] = $sum1[$col] + (1 - $recrdstuarray[$row][$col]) * $recrdstuarray[$row][$notestitems + 3];
			$sum3[$col] = $sum3[$col] + $recrdstuarray[$row][$notestitems + 3];
		}
		for ($row=$recrdstuarray[$nosturecs + 1][$col]; $row < $nosturecs; $row++) {
			$sum2[$col] = $sum2[$col] + $recrdstuarray[$row][$col] * $recrdstuarray[$row][$notestitems + 3];
		}
		for ($row=$nosturecs - $recrdstuarray[$nosturecs + 1][$col]; $row < $nosturecs; $row++) {
			$sum4[$col] = $sum4[$col] + $recrdstuarray[$row][$notestitems + 3];
		}
		//store col ci
		if ($sum3[$col] - $sum4[$col] != 0) {
			$recrdstuarray[$nosturecs + 2][$col]  = (int)(($sum1[$col] - $sum2[$col])/($sum3[$col] - $sum4[$col]) * 100);
		} else {
			$recrdstuarray[$nosturecs + 2][$col]  = 0;
		}
		//running total
		$sumitci = $sumitci + $recrdstuarray[$nosturecs + 2][$col];
	}
}


Function CalcIAItemDisc($recrdstuarray, $nosturecs, $notestitems, $typeia) {
	//item descrimination in half with any tied border scores in upper/lower go to omitted middle
	//recrdstuarray layout--col discrimination--$recrdstuarray[$nosturecs + 3][$col]
	global $recrdstuarray, $iagroupsize, $iatopgrp, $iabotgrp;
	if ($typeia == "split") {
		$iagroupsize = round(0.50 * $nosturecs); //IA calc for high & low splt half group sizes
	} else if ($typeia == "thirds") {
		$iagroupsize = round(0.33 * $nosturecs); //IA calc for high & low thirds group sizes
	}
	$iatopgrp = $iagroupsize;
	$iatopptr = $iagroupsize - 1; //array top group pointer
	$iabotgrp = $iagroupsize;
	$iabotptr = $nosturecs - $iagroupsize; //array bottom group pointer
	if (($typeia == "split") || ($typeia == "thirds")) { //trim group sizes
		//determine top boundaries checking next score for tie
		while ($recrdstuarray[$iatopptr][$notestitems + 3] == $recrdstuarray[$iatopptr + 1][$notestitems + 3]) { //iterate backwards until score change
			$iatopptr = $iatopptr - 1;
		}
		$iatopgrp = $iatopptr + 1; //corrected top grp size
		//determine bottom boundaries checking next score for tie
		while ($recrdstuarray[$iabotptr][$notestitems + 3] == $recrdstuarray[$iabotptr - 1][$notestitems + 3]) { //iterate backwards until score change
			$iabotptr = $iabotptr + 1;
		}
		$iabotgrp = $nosturecs - $iabotptr; //corrected bottom grp size
	}
	for ($col=3; $col < $notestitems + 3; $col++) {
		//calc high group
		$sumhigh = 0;
		for ($row=0; $row < $iatopgrp; $row++) {
			$sumhigh = $sumhigh + $recrdstuarray[$row][$col];
		}
		$highcorrect = ($sumhigh / $iatopgrp);
		//calc low group
		$sumlow = 0;
		for ($row=$nosturecs - $iabotgrp; $row < $nosturecs; $row++) {
			$sumlow = $sumlow + $recrdstuarray[$row][$col];
		}
		$lowcorrect = ($sumlow / $iabotgrp);
		//item discrimination
		$recrdstuarray[$nosturecs + 3][$col] = round(($highcorrect - $lowcorrect), 2);
		//item difficulty $itemdif = $recrdstuarray[$nosturecs + 1][$col] / $nosturecs;
	}
}


function CalcBiserialCorr($recrdstuarray, $notestitems, $nosturecs, $zm) {
	//item biserial correlation
	//recrdstuarray layout --col biserial-- $recrdstuarray[$nosturecs + 4][$col]
	global $recrdstuarray;
	for ($col=3; $col < $notestitems + 3; $col++) {
		$zsumxy = 0;
		$zsumxsq = 0;
		$zsumysq = 0;
		for ($row=0; $row < $nosturecs; $row++) {
			$zx = $zm - $recrdstuarray[$row][$notestitems + 3];
			$zy = ($recrdstuarray[$nosturecs + 1][$col] / $nosturecs) - $recrdstuarray[$row][$col];
			$zxsq = $zx * $zx;
			$zysq = $zy * $zy;
			$zsumxsq = $zsumxsq + $zxsq;
			$zsumysq = $zsumysq + $zysq;
			$zsumxy = $zsumxy + ($zx * $zy);
		}
		$zsdx = sqrt($zsumxsq / $nosturecs);
		$zsdy = sqrt($zsumysq / $nosturecs);
		if (($zsumxy == 0) || ($nosturecs * $zsdx * $zsdy == 0)) {
			$recrdstuarray[$nosturecs + 4][$col] = 0;
		} else {
			$recrdstuarray[$nosturecs + 4][$col] = round($zsumxy / ($nosturecs * $zsdx * $zsdy), 2);
		}
	}
}


function calciaprobdistractkey() {
	//secondary ans key developed around next best responses
}


function DispTestTOC() {
	//display table of contents
	echo '<table>';
	//table title line
	echo '<caption> CatTrax Table of Contents </caption>';
	echo '<tr><td id="forceleft"><a href="#summary">Summary & Take Notice</a></td><td>&nbsp</td><td id="forceleft">quick reference of participants and items requiring your attention</td></tr>';
	echo '<tr><td id="forceleft"><a href="#sptable">Participant & Item Interaction</a></td><td>&nbsp</td><td id="forceleft">interactions of ranked participants and items in graphical-numerical format</td></tr>';
	echo '<tr><td id="forceleft"><a href="#IA">Detailed Item Results</td><td>&nbsp</td><td id="forceleft">item analysis in ranked easy to hard listing</td></tr>';
	echo '<tr><td id="forceleft"><a href="#partlist">Detailed Participant Results</td><td>&nbsp</td><td id="forceleft">detailed participant results sorted by name</td></tr>';
	echo '<tr><td id="forceleft"><a href="#multikeys">Additional Keyed Results</td><td>&nbsp</td><td id="forceleft">results of primary answer key + any additional keys</td></tr>';
	echo '</table>';
	echo "<br />\n";
	echo "<br />\n";
}


function DispTestSummary($inputarray, $nosturecs, $notestitems, $notestkeys, $recrdstuarray, $inputfile, $zm, $zsd, $zkr20, $inputfilename) {
	//display summary table 1st key
	echo '<a name="summary"></a>';
	echo '<table>';
	//table title line
	echo '<caption> CatTrax Test Primary Key Summary </caption>';
	echo '<tr><th>Date</th><th>File</th><th>Participants</th><th>Items</th><th>Test Mean</th><th>Test Standard Deviation</th></tr>';
	$today = getdate();
	echo '<tr><td>' , $today['mon'] , '/' , $today['mday'] , '/' , $today['year'] ,'</td>';
	echo '<td>' , $inputfilename , '</td>';
	echo '<td>' , $nosturecs , '</td>';
	echo '<td>' , $notestitems , '</td>';
	echo '<td>' , round($zm, 1) , '</td>';
	echo '<td>' , round($zsd, 1) , '</td>';
	echo '</table>';
	echo "<br />\n";
}


function DispTestSummaryExtra($inputarray, $nosturecs, $notestitems, $notestkeys, $recrdstuarray, $inputfile, $zm, $zsd, $zkr20, $inputfilename, $keyptr) {
	//display summary table - 2nd and subsequent keys
	echo '<a name="multikeys"></a>';
	echo '<table>';
	//table title line
	echo '<caption> CatTrax Multiple Keys Summary -- Current + Preceding Keys</caption>';
	echo '<tr><th>KEY</th><th>Date</th><th>File</th><th>Participants</th><th>Items</th><th>Test Mean</th><th>Test Standard Deviation</th></tr>';
	$today = getdate();
	echo '<tr><td>' , $keyptr + 1 , '</td>';
	echo '<td>' , $today['mon'] , '/' , $today['mday'] , '/' , $today['year'] ,'</td>';
	echo '<td>' , $inputfilename , '</td>';
	echo '<td>' , $nosturecs , '</td>';
	echo '<td>' , $notestitems , '</td>';
	echo '<td>' , round($zm, 1) , '</td>';
	echo '<td>' , round($zsd, 1) , '</td>';
	echo '</table>';
	echo "<br />\n";
}


	function DisplayTeacherCaution($inputarray, $nosturecs, $notestitems, $notestkeys, $recrdstuarray, $iagroupsize, $iatopgrp, $iabotgrp, $zm, $zsd) {
	//display teacher caution table
	echo '<table>';
	echo '<caption> Take notice of the following participants (listed highest to lowest ranking)</caption>';
	echo '<tr><th>Id</th><th>Name</th><th>&nbsp</th><th>Issue</th>'; //table title line
	echo '</tr>';
	//table contents
	for ($row=0; $row < $nosturecs; $row++) {
		//calc zscore
		$zscore = ($recrdstuarray[$row][$notestitems + 3] - $zm) / $zsd;
		if (($zscore < -1) && ($recrdstuarray[$row][$notestitems + 4] >= 30)) { //low z and high CI
			echo '<td id="forcerightsmall">' , $recrdstuarray[$row][0] , '</td>'; //id
			echo '<td id="forceleftsmall">' , $recrdstuarray[$row][1] , '</td>'; //last
			echo '<td id="forceleftsmall">' , $recrdstuarray[$row][2] , '</td>'; //first
			echo '<td id="forceleftsmall">' , "is in the lower 15% of test scores and responding inconsistently when compared to similarly ranked participants" , '</td>'; //high CI & < -1 zscore
		} else if ($recrdstuarray[$row][$notestitems + 4] >= 30) { //CI check
			echo '<td id="forcerightsmall">' , $recrdstuarray[$row][0] , '</td>'; //id
			echo '<td id="forceleftsmall">' , $recrdstuarray[$row][1] , '</td>'; //last
			echo '<td id="forceleftsmall">' , $recrdstuarray[$row][2] , '</td>'; //first
			echo '<td id="forceleftsmall">' , "is responding inconsistently to the test items when compared to similarly ranked participants" , '</td>'; //high CI
		} else if ($zscore < -1) { //low z
			echo '<td id="forcerightsmall">' , $recrdstuarray[$row][0] , '</td>'; //id
			echo '<td id="forceleftsmall">' , $recrdstuarray[$row][1] , '</td>'; //last
			echo '<td id="forceleftsmall">' , $recrdstuarray[$row][2] , '</td>'; //first
			echo '<td id="forceleftsmall">' , "is in the lower 15% ranking of test scores " , '</td>'; //low zscore
		}
		echo '</tr>';
	}
	echo '</table>';
	echo "<br />\n";
	//display item take notice table
	echo '<table>';
	echo '<caption> Take notice of the following test items (listed easiest to hardest ranking)</caption>';
	echo '<tr><th>Item</th><th>Issue</th>';	//table title line
	echo '</tr>';
	for ($col=3; $col < $notestitems + 3; $col++) {
		if ((round($recrdstuarray[$nosturecs + 1][$col]  / $nosturecs) < .50 ) && ($recrdstuarray[$nosturecs + 2][$col] > 30) && ($recrdstuarray[$nosturecs + 3][$col] < 0 )) {
			echo '<td id="forcerightsmall">' , $recrdstuarray[$nosturecs][$col] , '</td>'; //item no
			echo '<td id="forceleftsmall">' , "is difficult, confusing, and not distinguishing between higher and lower ranking participants" , '</td>';
		} else if ((round($recrdstuarray[$nosturecs + 1][$col]  / $nosturecs) < .50 ) && ($recrdstuarray[$nosturecs + 2][$col] > 30)) {
			echo '<td id="forcerightsmall">' , $recrdstuarray[$nosturecs][$col] , '</td>'; //item no
			echo '<td id="forceleftsmall">' , "is difficult and confusing" , '</td>';
		} else if ((round($recrdstuarray[$nosturecs + 1][$col]  / $nosturecs) < .50 ) &&  ($recrdstuarray[$nosturecs + 3][$col] < 0 )) {
			echo '<td id="forcerightsmall">' , $recrdstuarray[$nosturecs][$col] , '</td>'; //item no
			echo '<td id="forceleftsmall">' , "is difficult and not distinguishing between higher and lower ranking participants" , '</td>';
		} else if (($recrdstuarray[$nosturecs + 2][$col] > 30) && ($recrdstuarray[$nosturecs + 3][$col] < 0 )) {
			echo '<td id="forcerightsmall">' , $recrdstuarray[$nosturecs][$col] , '</td>'; //item no
			echo '<td id="forceleftsmall">' , "is confusing and not distinguishing between higher and lower ranking participants" , '</td>';
		}  else if ($recrdstuarray[$nosturecs + 2][$col] > 30) {
			echo '<td id="forcerightsmall">' , $recrdstuarray[$nosturecs][$col] , '</td>'; //item no
			echo '<td id="forceleftsmall">' , "is confusing or poorly written" , '</td>';
		} else if ($recrdstuarray[$nosturecs + 3][$col] < 0 ) {
			echo '<td id="forcerightsmall">' , $recrdstuarray[$nosturecs][$col] , '</td>'; //item no
			echo '<td id="forceleftsmall">' , "is not distinguishing between higher and lower ranking participants" , '</td>';
		} else if (round($recrdstuarray[$nosturecs + 1][$col]  / $nosturecs) < .50 ) {
			echo '<td id="forcerightsmall">' , $recrdstuarray[$nosturecs][$col] , '</td>'; //item no
			echo '<td id="forceleftsmall">' , "is difficult with more than half of the group responding incorrectly" , '</td>';
		}
		//routine lists stats on bad items
		//if ((round($recrdstuarray[$nosturecs + 1][$col]  / $nosturecs) < .50 ) || ($recrdstuarray[$nosturecs + 2][$col] > 30) || ($recrdstuarray[$nosturecs + 3][$col] < 0 )) {
		//	echo '<td id="forcerightsmall">' , $recrdstuarray[$nosturecs][$col] , '</td>'; //item no
		//	echo '<td id="forcerightsmall">' , round(($recrdstuarray[$nosturecs + 1][$col]  / $nosturecs), 2) , '</td>'; //difficulty
		//	echo '<td id="forcerightsmall">' , $recrdstuarray[$nosturecs + 2][$col], '</td>'; //ci
		//	echo '<td id="forcerightsmall">' , $recrdstuarray[$nosturecs + 3][$col] , '</td>'; //discrimation
		//}
		echo '</tr>';
	}
	echo '</table>';
	echo "<br />\n";
	echo "<br />\n";
}


 function ExportTestSummary($inputarray, $nosturecs, $notestitems, $notestkeys, $recrdstuarray, $inputfile, $zm, $zsd, $zkr20, $inputfilename) {
	//export summary table
	$today = getdate();
	$today = ($today['mon'] . '/' . $today['mday'] . '/' . $today['year']);
	$line1 = array('Date', 'File', 'Participants', 'Items', 'Test Mean', 'Test SD');
	$line2 = array($today, $inputfilename, $nosturecs, $notestitems, round($zm, 1), round($zsd, 1));
	$line3 = array(' ');
	$csv = fopen('./cattraxfiles/outputcsv.csv', 'a');
	fputcsv($csv, $line1);
	fputcsv($csv, $line2);
	fputcsv($csv, $line3);
	fclose($csv);
}


 function ExportSP($inputarray, $nosturecs, $notestitems, $notestkeys, $recrdstuarray, $iagroupsize, $iatopgrp, $iabotgrp, $zm, $zsd) {
	//export sp table
	//table title line
	$csv = fopen('./cattraxfiles/outputcsv.csv', 'a');
	$line1 = array( 'Id', 'Name', '', 'CI', 'Tot', 'SEM', 'Range Lo', 'Range Hi', 'Z score');
	for ($col=3; $col < $notestitems + 3; $col++) {
		$line1[] = $recrdstuarray[$nosturecs][$col];
	}
	fputcsv($csv, $line1);
	//table contents
	for ($row=0; $row < $nosturecs; $row++) {
		$zscore = ($recrdstuarray[$row][$notestitems + 3] - $zm) / $zsd;
		$line3 = array($recrdstuarray[$row][0], $recrdstuarray[$row][1], $recrdstuarray[$row][2],
			$recrdstuarray[$row][$notestitems + 4], $recrdstuarray[$row][$notestitems + 3], round($recrdstuarray[$row][$notestitems + 5], 1),
			round($recrdstuarray[$row][$notestitems + 3] - $recrdstuarray[$row][$notestitems + 5], 0),
			round($recrdstuarray[$row][$notestitems + 3] + $recrdstuarray[$row][$notestitems + 5], 0),
			round($zscore, 2));
		for ($col=3; $col < $notestitems + 3; $col++) {
			if ($inputarray[$row + $notestkeys][$col] == ".") {
				$line3[] = '.';
			}else if ($inputarray[$row + $notestkeys][$col] == " ") {
				$line3[] = '.';
			} else {
				$line3[] = $recrdstuarray[$row][$col];
			}
		}
		fputcsv($csv, $line3);
	}
	//table item summary
	//items correct--$nosturecs + 1
	$line4 = array('', '', '', '', '', '', '', '', 'iTot');
	for ($col=3; $col < $notestitems + 3; $col++) {
		$line4[] =  $recrdstuarray[$nosturecs + 1][$col];
	}
	fputcsv($csv, $line4);
	//difficulty
	$line5 = array('', '', '', '', '', '', '', '', 'Diff');
	for ($col=3; $col < $notestitems + 3; $col++) {
		$line5[] = round(($recrdstuarray[$nosturecs + 1][$col]  / $nosturecs), 2);
	}
	fputcsv($csv, $line5);
	//CI--$nosturecs + 2
	$line6 = array('', '', '', '', '', '', '', '', 'CI');
	for ($col=3; $col < $notestitems + 3; $col++) {
		$line6[] = $recrdstuarray[$nosturecs + 2][$col];
	}
	fputcsv($csv, $line6);
	//discrimination--$nosturecs + 3
	$line7 = array('', '', '', '', '', '', '', '', 'Disc');
	for ($col=3; $col < $notestitems + 3; $col++) {
		$line7[] = $recrdstuarray[$nosturecs + 3][$col];
	}
	fputcsv($csv, $line7);
	fclose($csv);
}


//debugging
function DisplaySP($inputarray, $nosturecs, $notestitems, $notestkeys, $recrdstuarray, $iagroupsize, $iatopgrp, $iabotgrp, $zm, $zsd) {
	//display sp table
	echo '<a name="sptable"></a>';
	echo '<table>';
	//table title line
	echo '<caption> Participants listed highest to lowest ranking and Items listed easiest to hardest ranking</caption>';
	echo '<tr><th>Id</th><th>Name</th><th>&nbsp</th><th>CI</th><th>Tot</th><th>SEM</th><th>Range</th><th> Z </th>';
	for ($col=3; $col < $notestitems + 3; $col++) {
		echo '<th>' , $recrdstuarray[$nosturecs][$col] , '</th>';
	}
	echo '</tr>';
	//table contents
	for ($row=0; $row < $nosturecs; $row++) {
		if (($row == $iatopgrp - 1) || ($row == ($nosturecs - $iabotgrp) - 1)) { //ia boundaries
			echo '<tr class="border-bottom">';
		} else {
			echo '<tr>';
		}
		echo '<td id="forcerightsmall">' , $recrdstuarray[$row][0] , '</td>'; //id
		echo '<td id="forceleftsmall">' , $recrdstuarray[$row][1] , '</td>'; //last
		echo '<td id="forceleftsmall">' , $recrdstuarray[$row][2] , '</td>'; //first
		if ($recrdstuarray[$row][$notestitems + 4] < 30) { //CI check
			echo '<td>' , $recrdstuarray[$row][$notestitems + 4] , '</td>'; //CI ok
		} else {
			echo '<td id="CI">' , $recrdstuarray[$row][$notestitems + 4] , '</td>'; //CI highlight
		}
		echo '<td>' , $recrdstuarray[$row][$notestitems + 3] , '</td>'; //score
		echo '<td>' , round($recrdstuarray[$row][$notestitems + 5], 1) , '</td>'; //conditional SEM
		echo '<td>' , round($recrdstuarray[$row][$notestitems + 3] - $recrdstuarray[$row][$notestitems + 5], 0) , '&nbsp-&nbsp' , round($recrdstuarray[$row][$notestitems + 3] + $recrdstuarray[$row][$notestitems + 5], 0) ,'</td>'; //range
		$zscore = ($recrdstuarray[$row][$notestitems + 3] - $zm) / $zsd;
		echo '<td>' , round($zscore, 2) , '</td>'; //zscore
		for ($col=3; $col < $notestitems + 3; $col++) {
			//if ($inputarray[$row + $notestkeys][$col] == ".") { //show period omits as (.)
			//	echo '<td id="CI"> . </td>';
			//} else if ($inputarray[$row + $notestkeys][$col] == " ") { //show " " omits as (.)
			//	echo '<td id="CI"> . </td>';
			//} else {
			//echo '<td>' , $recrdstuarray[$row][$col] , '</td>';
			//}
			if ($recrdstuarray[$row][$col] == "1") { //show correct response
				// echo '<td>' , $recrdstuarray[$row][$col] , '</td>';
				echo '<td id="Correct">' , $recrdstuarray[$row][$col] , '</td>';
			} else if ($inputarray[$row + $notestkeys][$col] == ".") { //show period omits as (.)
					echo '<td id="Incorrect"> . </td>';
			} else if ($inputarray[$row + $notestkeys][$col] == " ") { //show " " omits as (.)
					echo '<td id="Incorrect"> . </td>';
			} else { // show incorrect response
				// echo '<td>' , $recrdstuarray[$row][$col] , '</td>';
				echo '<td id="Incorrect">' , $recrdstuarray[$row][$col] , '</td>';
			}
		}
		echo '</tr>';
	}
	//table item summary
	//items correct--$nosturecs + 1
	echo '<tr>';
	for ($col=0; $col < 7; $col++) {
		echo '<td> &nbsp </td>';
	}
	echo '<th>Tot:</th>';
	for ($col=3; $col < $notestitems + 3; $col++) {
		echo '<td>' , $recrdstuarray[$nosturecs + 1][$col], '</td>';
	}
	echo '</tr>';
	//difficulty
	echo '<tr>';
	for ($col=0; $col < 7; $col++) {
		echo '<td> &nbsp </td>';
	}
	echo '<th>Diff:</th>';
	for ($col=3; $col < $notestitems + 3; $col++) {
		echo '<td id="smalltype">' , round(($recrdstuarray[$nosturecs + 1][$col]  / $nosturecs), 2) , '</td>';
	}
	echo '</tr>';
	//CI--$nosturecs + 2
	echo '<tr>';
	for ($col=0; $col < 7; $col++) {
		echo '<td> &nbsp </td>';
	}
	echo '<th>CI:</th>';
	for ($col=3; $col < $notestitems + 3; $col++) {
		if ($recrdstuarray[$nosturecs + 2][$col] < 30) {
			echo '<td>' , $recrdstuarray[$nosturecs + 2][$col], '</td>';
		} else {
			echo '<td id="CI">' , $recrdstuarray[$nosturecs + 2][$col], '</td>';
		}
	}
	echo '</tr>';
	//discrimination--$nosturecs + 3
	echo '<tr>';
	for ($col=0; $col < 7; $col++) {
		echo '<td> &nbsp </td>';
	}
	echo '<th>Disc:</th>';
	for ($col=3; $col < $notestitems + 3; $col++) {
		echo '<td id="smalltype">' , $recrdstuarray[$nosturecs + 3][$col] , '</td>';
	}
	echo '</tr>';
	echo '</table>';
	echo "<br />\n";
	echo "<br />\n";
}



function CalcIAProblem($inputarray, $itemarray, $recrdstuarray, $ansarray, $nosturecs, $notestkeys, $notestitems, $iagroupsize, $totopts, $iatopgrp, $iabotgrp, $typeia) {
	//group ia data using $itemarray
	//order mc responses ($itemarray) ascending for presentation
	for ($col=3; $col < $notestitems + 3; $col++) {
		$gap = (int)($itemarray[0][$col] / 2);
		while ($gap >= 1) {
			$sorted = 0;
			while ($sorted == 0) {
				$sorted = 1;
				$maxrow = $itemarray[0][$col] - $gap;
				for ($row=1; $row < $maxrow + 1; $row++) {
					$rowck = $row + $gap;
					if ($itemarray [$row][$col] > $itemarray [$rowck][$col]) {
						$swap = $itemarray[$row][$col];
						$itemarray[$row][$col] = $itemarray[$rowck][$col];
						$itemarray[$rowck][$col] = $swap;
						$sorted = 0;
					}
				}
			}
			$gap = (int)($gap / 2);
		}
	}
	//initialize ia group distribution array
	for ($initcol=0; $initcol < $totopts + 2; $initcol++) {
		for ($initrow=0; $initrow < 4; $initrow++) {
			$optiono[$initrow][$initcol] = "0";
		}
	}
	//establish group distributions
	//open export file append
	$csv = fopen('./cattraxfiles/outputcsv.csv', 'a');
	//Title displayed IA
	DisplayIAHeading($typeia);
	for ($col=3; $col < $notestitems + 3; $col++) {
		//high group
		for ($row=$notestkeys; $row < $iatopgrp + $notestkeys; $row++) {
			for ($cnt=1; $cnt < $itemarray[0][$col] + 1; $cnt++) { //range for all responses
				if ($inputarray[$row][$col] == $itemarray[$cnt][$col]) {
					$optiono[0][$cnt - 1]++;
				}
			}
		}
		//middle group
		for ($row=$iatopgrp + $notestkeys; $row < $nosturecs - $iabotgrp + $notestkeys; $row++) {
			for ($cnt=1; $cnt < $itemarray[0][$col] + 1; $cnt++) {
				if ($inputarray[$row][$col] == $itemarray[$cnt][$col]) {
					$optiono[1][$cnt - 1]++;
				}
			}
		}
		//low group
		for ($row=$nosturecs - $iabotgrp + $notestkeys; $row < $nosturecs + $notestkeys; $row++) {
			for ($cnt=1; $cnt < $itemarray[0][$col] + 1; $cnt++) {
				if ($inputarray[$row][$col] == $itemarray[$cnt][$col]) {
					$optiono[2][$cnt - 1]++;
				}
			}
		}
		//display IA results
		DisplayIAProbResultsmulti($recrdstuarray, $ansarray, $itemarray, $nosturecs, $notestkeys, $notestitems, $col, $totopts, $iagroupsize, $optiono, $iatopgrp, $iabotgrp, $typeia);
		exportiaprobresultsmulti($csv, $recrdstuarray, $ansarray, $itemarray, $nosturecs, $notestkeys, $notestitems, $col, $totopts, $iagroupsize, $optiono, $iatopgrp, $iabotgrp, $typeia);
		//calculate alternate distractor next best response key when one ans key
		if ($notestkeys == 1) {
			//calciaprobdistractkey();
		}
		//initialize ia group distribution array
		for ($initcol=0; $initcol < $totopts + 2; $initcol++) {
			for ($initrow=0; $initrow < 4; $initrow++) {
				$optiono[$initrow][$initcol] = "0";
			}
		}
	}
	//close append export file
	fclose($csv);
}


function DisplayIAHeading($typeia) {
	echo '<a name="IA"></a>';
	echo '<table border="0">';
	echo '<tr><th> Item Analysis (listed easiest to hardest ranking)</th></tr>';
	if ($typeia == "split") {
		echo '<tr><td id="forceleftsmall"> Split-Half (any tied high/low border scores show as a middle group)</td></tr>';
	} else if ($typeia == "thirds") {
		echo '<tr><td id="forceleftsmall"> Three Group (any tied border scores show in middle group) </td></tr>';
	}
	echo '<tr><td id="forceleftsmall">Legend (* keyed/correct response) (. omitted responses)</td></tr>';
	echo '</table>';
	echo "<br />\n";
}


function DisplayIAProbResultsmulti($recrdstuarray, $ansarray, $itemarray, $nosturecs, $notestkeys, $notestitems, $col, $totopts, $iagroupsize, $optiono, $iatopgrp, $iabotgrp, $typeia) {
	//format for display ia output
	echo '<table border="0">';
	echo '<tr><th>Item: ' ,$recrdstuarray[$nosturecs][$col] , '</th></tr>';
	echo '<tr><td id="forceleft"> Diff: ' , round(($recrdstuarray[$nosturecs + 1][$col] / $nosturecs), 2) , '&nbsp;&nbsp;&nbsp;&nbsp;Disc: ' , $recrdstuarray[$nosturecs + 3][$col] ,
	'&nbsp;&nbsp;&nbsp;&nbsp;CI: ' , $recrdstuarray[$nosturecs + 2][$col] , '</td></tr>';
	echo '</table>';
	echo '<table border="0">';
	echo '<tr><td>Group</th><td>N</td>';
	//item option titling
	for ($cnt=1; $cnt < $itemarray[0][$col] + 1; $cnt++) {
		//identify keyed option using 1st (0) answer key ($ansarray) with mc response options ($optionstr)
		if ($ansarray[0][$col] == $itemarray[$cnt][$col]) {
			echo '<td>*' , substr($itemarray[$cnt][$col], 0, 3) , '</td>'; //display only first 3 chars of response option
		} else {
			echo '<td>' , substr($itemarray[$cnt][$col], 0, 3) , '</td>';
		}
	}
	echo '</tr>';
	echo '<tr>';
	//high-middle-low group outputs
	for ($grp=0; $grp < 3; $grp++) {
		//titling and three group within totals
		if ($grp == 0) {
			echo '<td id="forceleft">High</td>';
			echo '<td>' , substr($iatopgrp, 0, 3) , '</td>';
			for ($optn=0; $optn < $itemarray[0][$col]; $optn++) { //item col totals
				echo '<td>' , substr($optiono[$grp][$optn], 0, 3) , '</td>';
				$optiono[3][$optn] = $optiono[3][$optn] + $optiono[$grp][$optn];
			}
		} else if ($grp == 1) {
			if (substr($nosturecs - ($iatopgrp + $iabotgrp), 0, 3) > 0) {
				echo '<td id="forceleft">Middle</td>';
				echo '<td>' , substr($nosturecs - ($iatopgrp + $iabotgrp), 0, 3) , '</td>';
				for ($optn=0; $optn < $itemarray[0][$col]; $optn++) { //item col totals
					echo '<td>' , substr($optiono[$grp][$optn], 0, 3) , '</td>';
					$optiono[3][$optn] = $optiono[3][$optn] + $optiono[$grp][$optn];
				}
			}
		} else {
			echo '<td id="forceleft">Low</td>';
			echo '<td>' , substr($iabotgrp, 0, 3) , '</td>';
			for ($optn=0; $optn < $itemarray[0][$col]; $optn++) { //item col totals
				echo '<td>' , substr($optiono[$grp][$optn], 0, 3) , '</td>';
				$optiono[3][$optn] = $optiono[3][$optn] + $optiono[$grp][$optn];
			}
		}
		echo '</tr>';
	}
	//totals line
	echo '<tr><td id="forceleft">Total</td>';
	echo '<td>' , substr($nosturecs, 0, 3) , '</td>';
    for ($cnt=0; $cnt < $itemarray[0][$col]; $cnt++) {
		echo '<td>' , substr($optiono[3][$cnt], 0, 3) , '</td>';
	}
	echo '</tr>';
	echo '</table>';
	//Response legend
	echo '<br />';
	echo '<table border="0">';
	for ($cnt=1; $cnt < $itemarray[0][$col] + 1; $cnt++) {
		$a = $itemarray[$cnt][$col];
		if ((strlen($a) > 3)) { //check for long response
			echo '<tr><td>' , substr($itemarray[$cnt][$col], 0, 3) , '</td><td>&nbsp=&nbsp</td><td>' , $itemarray[$cnt][$col] , '</td></tr>';
		}
	}
	echo '</table>';
	//echo "<br />\n";
}


 function exportiaprobresultsmulti($csv, $recrdstuarray, $ansarray, $itemarray, $nosturecs, $notestkeys, $notestitems, $col, $totopts, $iagroupsize, $optiono, $iatopgrp, $iabotgrp, $typeia) {
	//format for csv export ia output
	$line0 = array(' ');
	fputcsv($csv, $line0);
	$line1 = array('ITEM: ' . $recrdstuarray[$nosturecs][$col]);
	fputcsv($csv, $line1);
	if ($typeia == "split") {
		$line2 = array('Split-Half: IA tied high/low border scores show as middle group');
	} else if ($typeia == "thirds") {
		$line2 = array('Three group IA: tied border scores show in middle group');
	}
	fputcsv($csv, $line2);
	$line3 = array('Diff: ' , round(($recrdstuarray[$nosturecs + 1][$col] / $nosturecs), 2) , 'Disc: ' , $recrdstuarray[$nosturecs + 3][$col] ,
	'CI: ' , $recrdstuarray[$nosturecs + 2][$col]);
	fputcsv($csv, $line3);
	$line4 = array('Group', 'N');

	//item option titling
	for ($cnt=1; $cnt < $itemarray[0][$col] + 1; $cnt++) {
		//identify keyed option using 1st (0) answer key ($ansarray) with mc response options ($optionstr)
		if ($ansarray[0][$col] == $itemarray[$cnt][$col]) {
			$line4[] = '*' . substr($itemarray[$cnt][$col], 0, 3); //display only first 3 chars of response option
		} else {
			$line4[] = substr($itemarray[$cnt][$col], 0, 3);
		}
	}
	fputcsv($csv, $line4);
	echo '<tr>';
	for ($grp=0; $grp < 3; $grp++) {
	//IA block titling and within totals
		if ($grp == 0) {
			$line6 = array('High' , substr($iatopgrp, 0, 3));
			for ($optn=0; $optn < $itemarray[0][$col]; $optn++) {
				$line6[] = substr($optiono[$grp][$optn], 0, 3);
				$optiono[3][$optn] = $optiono[3][$optn] + $optiono[$grp][$optn];
			}
			fputcsv($csv, $line6);
		} else if ($grp == 1) {
			if (substr($nosturecs - ($iatopgrp + $iabotgrp), 0, 3) > 0) {
				$line6 = array('Middle' , substr($nosturecs - ($iatopgrp + $iabotgrp), 0, 3));
				for ($optn=0; $optn < $itemarray[0][$col]; $optn++) {
					$line6[] = substr($optiono[$grp][$optn], 0, 3);
					$optiono[3][$optn] = $optiono[3][$optn] + $optiono[$grp][$optn];
				}
				fputcsv($csv, $line6);
			}
		} else {
			$line6 = array('Low' , substr($iabotgrp, 0, 3));
			for ($optn=0; $optn < $itemarray[0][$col]; $optn++) {
				$line6[] = substr($optiono[$grp][$optn], 0, 3);
				$optiono[3][$optn] = $optiono[3][$optn] + $optiono[$grp][$optn];
			}
			fputcsv($csv, $line6);
		}
	}
	//totals line
	$line7 = array('Total' , substr($nosturecs, 0, 3));
	for ($cnt=0; $cnt < $itemarray[0][$col]; $cnt++) {
		$line7[] = substr($optiono[3][$cnt], 0, 3);
	}
	fputcsv($csv, $line7);


	//Response legend
	for ($cnt=1; $cnt < $itemarray[0][$col] + 1; $cnt++) {
		$a = $itemarray[$cnt][$col];
		if ((strlen($a) > 3)) { //check for long response
			$line8 = array(substr($itemarray[$cnt][$col], 0, 3) , $itemarray[$cnt][$col]);
			fputcsv($csv, $line8);
		}
	}
}


Function NameExportCSV() {
	//create random number file name & rename csv output file
	//$randno = rand(0000,9999);
    //$timestamp = date("Y_m_d_H_i_s");
	//$action = $randno . '_' . $timestamp;
	//rename('./cattraxfiles/outputcsv.csv', './cattraxfiles/' . $action . '.csv');
	echo '<a href=\'index.php?action='.$action.'\'>Get your cattrax input data and results as a CSV file</a>';
}


Function Downloadcsv($action) {
	//$file = './cattraxfiles/' . $action . '.csv';
	$file = './cattraxfiles/outputcsv.csv';
    if (file_exists($file)) {
        //set appropriate headers
        ob_start();
        header('Content-Description: File Transfer');
        header('Content-Type: application/csv');
        header('Content-Disposition: attachment; filename='.basename($file));
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file)); 
        ob_clean();
        flush();
        readfile($file);
        exit;
    } else {
		echo 'Cattrax CSV formatted file not found';
	exit;
	}
}


function SortName($recrdstuarray, $inputarray, $nosturecs, $notestkeys, $notestitems) {
	//sort rows by name alpha
	global $recrdstuarray, $inputarray;
	$gap = (int)($nosturecs / 2);
	while ($gap >= 1) {
		$sorted = 0;
		while ($sorted == 0) {
			$sorted = 1;
			$maxrow = $nosturecs - $gap;
			for ($row=0; $row < $maxrow; $row++) {
				$rowck = $row + $gap;
				if ($recrdstuarray [$row][1] > $recrdstuarray [$rowck][1]) {
					for ($col=0; $col < $notestitems + 6; $col++) { //+3score tot +4CI +5SDs
						//swap stu/item scored array
						$swap = $recrdstuarray [$row][$col];
						$recrdstuarray [$row][$col] = $recrdstuarray [$rowck][$col];
						$recrdstuarray [$rowck][$col] = $swap;
					}
					for ($col=0; $col < $notestitems + 3; $col++) {
						//swap raw input array bypassing ans keys
						$swap = $inputarray[$row + $notestkeys][$col];
						$inputarray [$row + $notestkeys][$col] = $inputarray [$rowck + $notestkeys][$col];
						$inputarray [$rowck + $notestkeys][$col] = $swap;
					}
					$sorted = 0;
				}
			}
		}
		$gap = (int)($gap / 2);
	}
}


function SortItem($recrdstuarray, $ansarray, $inputarray, $itemarray, $nosturecs, $notestkeys, $notestitems, $totopts){
	//sort cols by descending item scores
	//sort cols by ascending item number
	global $recrdstuarray, $ansarray, $inputarray, $itemarray;
	$gap = (int)($notestitems / 2);
	while ($gap >= 1) {
		$sorted = 0;
		while ($sorted == 0) {
			$sorted = 1;
			$maxcol = ($notestitems + 3) - $gap;
			for ($col=3; $col < $maxcol; $col++) {
				$colck = $col + $gap;
				//if ($recrdstuarray [$nosturecs + $notestkeys][$col] < $recrdstuarray [$nosturecs + $notestkeys][$colck]) {
				if ($recrdstuarray [$nosturecs][$col] > $recrdstuarray [$nosturecs][$colck]) {
					//swap stu/item scored array
					for ($row=0; $row < $nosturecs + 2; $row++) {
						$swap = $recrdstuarray [$row][$col];
						$recrdstuarray [$row][$col] = $recrdstuarray [$row][$colck];
						$recrdstuarray [$row][$colck] = $swap;
					}
					//sort ans key
					for ($row=0; $row < $notestkeys; $row++) {
						$swap = $ansarray[$row][$col];
						$ansarray[$row][$col] = $ansarray[$row][$colck];
						$ansarray[$row][$colck] = $swap;
					}
					//sort item responses array
					for ($row=0; $row < $totopts + 1; $row++) {
						$swap = $itemarray[$row][$col];
						$itemarray[$row][$col] = $itemarray[$row][$colck];
						$itemarray[$row][$colck] = $swap;
					}
					//sort raw input array
					for ($row=0; $row < $nosturecs + $notestkeys; $row++) {
						$swap = $inputarray [$row][$col];
						$inputarray [$row][$col] = $inputarray [$row][$colck];
						$inputarray [$row][$colck] = $swap;
					}
					$sorted = 0;
				}
			}
		}
		$gap = (int)($gap / 2);
	}
}


function DisplayRoster($inputarray, $nosturecs, $notestitems, $notestkeys, $recrdstuarray, $iagroupsize, $iatopgrp, $iabotgrp, $zm, $zsd, $keyptr){
	//display list of participants and detailed results by item
	echo '<a name="partlist"></a>';
	echo "<br />\n";
	echo '<table>';
	//table title line
	echo '<caption> Participants listed alphabetically and Items listed numerically</caption>';
	echo '<tr><th>Id</th><th>Name</th><th>&nbsp</th><th>CI</th><th>Tot</th><th>SEM</th><th>~Range</th><th> Z </th>';
	//show item numbers
	for ($col=3; $col < $notestitems + 3; $col++) {
		echo '<th>' , $recrdstuarray[$nosturecs][$col] , '</th>';
	}
	echo '</tr>';
	//kitty
	//show ans key
	for ($anskey=0; $anskey < $keyptr + 1; $anskey++) {
		echo '<tr>';
		echo '<td></td><td id="smalltype">Key: ' , $anskey + 1 , '</td><td></td><td></td><td></td><td></td><td></td><td></td>';
		for ($col=3; $col < $notestitems + 3; $col++) {
			echo '<td id="smalltype">' , $inputarray[$anskey][$col] , '</td>';
		}
		echo '</tr>';
	}

	//show table contents
	for ($row=0; $row < $nosturecs; $row++) {
		echo '<tr>';
		echo '<td id="forcerightsmall">' , $recrdstuarray[$row][0] , '</td>'; //id
		echo '<td id="forcerightsmallbold">' , $recrdstuarray[$row][1] , '</td>'; //last
		echo '<td id="forceleftsmall">' , $recrdstuarray[$row][2] , '</td>'; //first
		if ($recrdstuarray[$row][$notestitems + 4] < 30) { //CI check
			echo '<td>' , $recrdstuarray[$row][$notestitems + 4] , '</td>'; //CI ok
		} else {
			echo '<td id="CI">' , $recrdstuarray[$row][$notestitems + 4] , '</td>'; //CI highlight
		}
		echo '<td id="Tot">' , $recrdstuarray[$row][$notestitems + 3] , '</td>'; //score
		echo '<td>' , round($recrdstuarray[$row][$notestitems + 5], 1) , '</td>'; //conditional SEM
		echo '<td id="Range">' , round($recrdstuarray[$row][$notestitems + 3] - $recrdstuarray[$row][$notestitems + 5], 0) , '--' , $recrdstuarray[$row][$notestitems + 3] , '--' , round($recrdstuarray[$row][$notestitems + 3] + $recrdstuarray[$row][$notestitems + 5], 0) ,'</td>'; //range
		$zscore = ($recrdstuarray[$row][$notestitems + 3] - $zm) / $zsd;
		echo '<td>' , round($zscore, 2) , '</td>'; //zscore
		for ($col=3; $col < $notestitems + 3; $col++) {
			if ($recrdstuarray[$row][$col] == "1") { //show correct response
				echo '<td id="Correct">' , $inputarray[$row + $notestkeys][$col] , '</td>';
				//echo '<td id="Correct">' , $recrdstuarray[$row][$col] , '</td>';
			} else if ($inputarray[$row + $notestkeys][$col] == ".") { //show period omits as (.)
					echo '<td id="Incorrect"> . </td>';
			} else if ($inputarray[$row + $notestkeys][$col] == " ") { //show " " omits as (.)
					echo '<td id="Incorrect"> . </td>';
			} else { // show incorrect response
				echo '<td id="Incorrect">' , $inputarray[$row + $notestkeys][$col] , '</td>';
				//echo '<td id="Incorrect">' , $recrdstuarray[$row][$col] , '</td>';
			}
		}
		echo '</tr>';
	}
	//table item summary
	echo '<tr>';
	for ($col=0; $col < 7; $col++) {
		echo '<td> &nbsp </td>';
	}
	echo '<th id="smalltype">Tot:</th>';
	for ($col=3; $col < $notestitems + 3; $col++) {
		echo '<td id="smalltype">' , $recrdstuarray[$nosturecs + 1][$col], '</td>';
	}
	echo '</tr>';
	//difficulty
	echo '<tr>';
	for ($col=0; $col < 7; $col++) {
		echo '<td> &nbsp </td>';
	}
	echo '<th id="smalltype">Diff:</th>';
	for ($col=3; $col < $notestitems + 3; $col++) {
		echo '<td id="smalltype">' , round(($recrdstuarray[$nosturecs + 1][$col]  / $nosturecs), 2) , '</td>';
	}
	echo '</tr>';
	//CI--$nosturecs + 2
	echo '<tr>';
	for ($col=0; $col < 7; $col++) {
		echo '<td> &nbsp </td>';
	}
	echo '<th id="smalltype">CI:</th>';
	for ($col=3; $col < $notestitems + 3; $col++) {
		if ($recrdstuarray[$nosturecs + 2][$col] < 30) {
			echo '<td id="smalltype">' , $recrdstuarray[$nosturecs + 2][$col], '</td>';
		} else {
			echo '<td id="CI">' , $recrdstuarray[$nosturecs + 2][$col], '</td>';
		}
	}
	echo '</tr>';
	//discrimination--$nosturecs + 3
	echo '<tr>';
	for ($col=0; $col < 7; $col++) {
		echo '<td> &nbsp </td>';
	}
	echo '<th id="smalltype">Disc:</th>';
	for ($col=3; $col < $notestitems + 3; $col++) {
		echo '<td id="smalltype">' , $recrdstuarray[$nosturecs + 3][$col] , '</td>';
	}
	echo '</tr>';
	echo '</table>';
	echo "<br />\n";
	echo "<br />\n";
}

function DiagnosticDump($inputarray, $nosturecs, $notestitems, $notestkeys, $recrdstuarray) {
	//echo "<h5>student recs $nosturecs</h5>";
	//echo "<h5>test items $notestitems </h5>";
	//echo "<h5>ans keys $notestkeys</h5>";
	//echo "<h5>inputarray</h5>";
	for ($row=0; $row < $nosturecs + $notestkeys; $row++) {
		for ($col=0; $col < $notestitems + 3; $col++) {
			echo $inputarray[$row][$col];
		}
		echo "<br />\n";
	}
		//**dump array**
	echo "<h5> recrdstuarray</h5>";
	for ($row=0; $row < $nosturecs + 5; $row++) {
		//echo "<h5> row $row </h5>";
		for ($col=0; $col < $notestitems + 6; $col++) {
			echo $recrdstuarray[$row][$col];
		}
		echo "<br />\n";
	}

	//echo "";
	//print_r($recrdstuarray);
	//echo "";
}   
?>
</body>
</html>
